# Governance Boundary

No AI-generated output should be shown to a patient or used in clinical workflow without human clinical review.

The system is suitable for:

- synthetic demo;
- de-identified case review preparation;
- teaching;
- workflow governance;
- quality improvement discussion;
- patient education drafts after review.

The system is not suitable for:

- direct patient treatment;
- emergency replacement;
- prescribing;
- procedure scheduling;
- automatic triage decisions;
- transplant listing.
