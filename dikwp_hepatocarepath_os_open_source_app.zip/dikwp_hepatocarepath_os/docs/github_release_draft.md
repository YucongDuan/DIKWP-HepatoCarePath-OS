# GitHub Release Draft

## DIKWP HepatoCarePath OS v0.1.0

A review-only liver hospital workflow system for triage preparation, treatment discussion preparation, rehabilitation support and AI safety governance.

Highlights:

- DIKWP liver ledger
- red flag routing
- missing evidence queue
- clinician handoff
- patient education draft
- AI request guard
- static boundary audit
- standalone demo

This is not a medical device and does not provide diagnosis or treatment.
