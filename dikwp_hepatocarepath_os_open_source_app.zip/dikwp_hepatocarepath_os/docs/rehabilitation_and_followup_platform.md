# Rehabilitation and Follow-up Platform

The rehabilitation plan supports long-term liver disease management after clinical review.

Focus areas:

- fatigue pacing;
- nutrition and malnutrition risk discussion;
- alcohol and substance support;
- medication safety;
- sleep and mental health;
- stigma and family education;
- appointment and lab tracking;
- transport/cost/work barriers;
- surveillance reminders.

Rehab must pause when red flags are present until urgent clinical review is complete.
