# Clinical Governance Boundary

This system is a review-preparation and governance system.

It cannot be used as:

- diagnostic software;
- prescribing software;
- transplant listing software;
- cancer diagnosis software;
- emergency triage automation;
- procedure scheduling automation;
- medical device control software.

All patient-specific decisions require licensed clinician review under local hospital governance.
