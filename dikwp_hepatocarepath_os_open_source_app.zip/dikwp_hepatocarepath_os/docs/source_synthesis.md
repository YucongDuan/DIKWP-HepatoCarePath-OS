# Source Synthesis

The system is designed around public health, hepatology and healthcare AI governance anchors:

- viral hepatitis remains a major global liver disease burden;
- MASLD/MASH terminology and metabolic liver disease require structured evidence;
- AI in healthcare must remain governed, locally validated and human-supervised;
- liver disease triage requires urgent escalation for red flags;
- rehabilitation and long-term follow-up are part of liver care;
- DIKWP provides the semantic structure to organize incomplete, imprecise and inconsistent inputs.
