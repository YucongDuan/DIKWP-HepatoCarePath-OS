# Liver Hospital Workflow

## Intake

Patients may arrive through outpatient triage, emergency, referral, inpatient consult, screening, follow-up or rehabilitation services.

## DIKWP preparation

The system prepares a review packet:

- symptoms and onset;
- labs and imaging;
- virology and metabolic risk;
- red flags;
- missing evidence;
- route and reviewer;
- patient goals.

## Treatment preparation

The system prepares questions for clinicians. It never prescribes antiviral therapy, diuretics, steroids, immune suppression, antibiotics, anti-cancer therapy or transplant decisions.

## Rehabilitation

The rehabilitation draft focuses on adherence, fatigue pacing, nutrition coordination, alcohol/substance support, stigma, sleep, follow-up barriers and patient education after clinician review.
