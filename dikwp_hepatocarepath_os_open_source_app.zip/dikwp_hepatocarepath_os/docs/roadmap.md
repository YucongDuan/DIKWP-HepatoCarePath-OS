# Roadmap

## v0.2

- add more synthetic cases;
- add disease-specific templates;
- add liver tumor board review pack;
- add transplant referral preparation boundary;
- add multilingual patient education drafts.

## v0.3

- add FHIR-like import adapter for de-identified data;
- add local model registry validation pack;
- add outcome and follow-up dashboard.

## v1.0

- pilot in liver hospital dry-run environment;
- publish external validation report;
- integrate TrustPassport and ProofLedger.
