# Treatment Preparation Boundary

Allowed:

- collect missing evidence;
- prepare clinician questions;
- organize medication/supplement list;
- flag interaction review needs;
- prepare patient education draft;
- prepare MDT/liver board review agenda.

Blocked:

- prescribe antiviral therapy;
- recommend dosing;
- decide transplant eligibility;
- schedule procedures;
- stop or start medications;
- replace emergency care;
- infer malignancy from one marker.
