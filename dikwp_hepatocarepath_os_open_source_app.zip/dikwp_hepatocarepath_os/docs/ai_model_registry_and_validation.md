# AI Model Registry and Validation

Each AI component must have a model card:

- intended use;
- prohibited uses;
- data inputs;
- validation status;
- max control level;
- clinician review requirement;
- failure modes;
- local validation plan.

No AI model in the reference implementation is allowed to diagnose, prescribe or schedule procedures.
