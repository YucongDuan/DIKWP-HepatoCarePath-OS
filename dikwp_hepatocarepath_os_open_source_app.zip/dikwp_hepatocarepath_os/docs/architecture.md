# Architecture

DIKWP HepatoCarePath OS has six offline modules.

1. **Case Intake** reads structured synthetic or de-identified case JSON.
2. **Topic Router** detects HBV, HCV, MASLD/MASH, cirrhosis, HCC, DILI and autoimmune/cholestatic signals.
3. **Red Flag Boundary** upgrades urgent patterns such as confusion, bleeding, rapidly worsening jaundice, possible liver failure pattern, and fever with ascites.
4. **DIKWP Ledger** converts case data into D/I/K/W/P/R.
5. **Action Ticket Engine** creates triage, treatment-prep and rehab review tickets.
6. **Report Generator** outputs JSON and markdown files for clinician review.

The offline core has no network, no browser automation, no medical-device control and no clinical automation.
