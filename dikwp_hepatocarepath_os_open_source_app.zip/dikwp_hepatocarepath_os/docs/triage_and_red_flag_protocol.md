# Triage and Red Flag Protocol

The system uses red flags only to route the case to human clinician review.

Examples include:

- confusion or possible encephalopathy;
- vomiting blood or black stool;
- severe or rapidly worsening jaundice;
- fever with ascites;
- severe abdominal pain;
- very high liver enzymes;
- elevated INR with high bilirubin;
- suspected acetaminophen or supplement injury;
- renal dysfunction in liver disease.

The system does not diagnose acute liver failure, cirrhosis, HCC or hepatitis. It prepares an escalation packet.
