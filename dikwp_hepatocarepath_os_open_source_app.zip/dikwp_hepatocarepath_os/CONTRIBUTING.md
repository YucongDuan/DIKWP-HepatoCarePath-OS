# Contributing

Contributions must preserve the clinical boundary: no diagnosis, prescribing, procedure scheduling, transplant listing, patient-specific treatment instructions, or medical device control.

Use synthetic or de-identified data only.
