# Security Policy

Report issues involving data leakage, clinical automation, hidden telemetry, credential capture, unsafe medical outputs or harmful misuse.

The offline core should not include network access, subprocess calls, browser automation or credential handling.
