from pathlib import Path
from dikwp_hepatocarepath.analyzer import load_case, analyze_case, guard_ai_request
from dikwp_hepatocarepath.static_audit import run_static_audit

ROOT = Path(__file__).resolve().parents[1]

def test_demo_case_routes_to_review_or_urgent():
    case = load_case(ROOT / "examples" / "sample_liver_hospital_case.json")
    bundle = analyze_case(case)
    assert bundle.summary["route"] in {"urgent_specialist_or_emergency_review", "specialist_hepatology_review_required", "clinician_review_required"}
    assert bundle.summary["missing_evidence_count"] >= 1
    assert len(bundle.decision_cards) == 1


def test_guard_blocks_prescribing():
    result = guard_ai_request("Dose antiviral therapy for this patient")
    assert result["decision"] == "block"


def test_static_audit_passes_core():
    report = run_static_audit(ROOT / "src")
    assert report["pass"] is True
