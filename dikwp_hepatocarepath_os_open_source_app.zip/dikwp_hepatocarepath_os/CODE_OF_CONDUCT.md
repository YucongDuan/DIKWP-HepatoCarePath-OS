# Code of Conduct

Be respectful, evidence-oriented, safety-aware and clinically conservative. Do not use this project to pressure clinicians or patients into unsafe actions.
