# Recommendations

- Use this output only as a review packet.
- Confirm urgency, diagnosis, staging, and treatment with licensed clinicians.
- Keep patient identity and sensitive data out of demo workflows.
- Run local validation before any real clinical deployment.