# Patient Education Draft

This draft is for clinician review before patient use. It is not a diagnosis or treatment instruction.

## Safety First
Some symptoms or lab patterns in the record may require urgent clinical review. Do not use lifestyle or rehabilitation advice to delay urgent care.
## What to Prepare for the Visit
- Bring medication and supplement list.
- Bring prior lab reports and imaging dates.
- Write down symptoms, onset time, alcohol/supplement exposure, and patient goals.
- Ask which findings are confirmed, suspected, or still unknown.
## Follow-up Questions
- For HBV: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.
- For MASLD/MASH: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.
- For Alcohol-related liver disease: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.
- For Cirrhosis / portal hypertension: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.
- For HCC surveillance: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.
- For DILI / herb-supplement injury: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.
## Red Flag Reminder
Seek urgent medical care for confusion, vomiting blood, black stools, severe abdominal pain, fainting, rapidly worsening jaundice, or fever with ascites.