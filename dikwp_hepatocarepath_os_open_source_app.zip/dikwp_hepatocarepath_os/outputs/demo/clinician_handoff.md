# Clinician Handoff Draft

Case ID: hepatocare-demo-001
Setting: specialty liver hospital outpatient-to-inpatient triage demo

## Suspected Topic Signals
- HBV
- MASLD/MASH
- Alcohol-related liver disease
- Cirrhosis / portal hypertension
- HCC surveillance
- DILI / herb-supplement injury

## Red Flags
- confusion
- jaundice severe
- possible acute liver failure pattern: INR and bilirubin elevated

## Missing Evidence Queue
- anti_HBs
- blood_pressure
- encephalopathy_history
- lipids

## Proposed Route
urgent_specialist_or_emergency_review

## Boundary
This handoff prepares review. It does not diagnose, prescribe, stage disease, or schedule procedures.
