from __future__ import annotations
import argparse, json
from pathlib import Path
from .analyzer import load_case, analyze_case, save_report, guard_ai_request
from .static_audit import run_static_audit

def main():
    parser = argparse.ArgumentParser(prog="hepatocare", description="DIKWP HepatoCarePath OS CLI")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("analyze")
    p.add_argument("case_json")
    p.add_argument("--out", default="outputs/demo")
    g = sub.add_parser("guard")
    g.add_argument("request")
    a = sub.add_parser("static-audit")
    a.add_argument("path")
    a.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.cmd == "analyze":
        case = load_case(args.case_json)
        bundle = analyze_case(case)
        save_report(bundle, args.out)
        print(json.dumps(bundle.summary, ensure_ascii=False, indent=2))
    elif args.cmd == "guard":
        print(json.dumps(guard_ai_request(args.request), ensure_ascii=False, indent=2))
    elif args.cmd == "static-audit":
        report = run_static_audit(args.path)
        out = Path(args.out); out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
