from __future__ import annotations
from pathlib import Path
import ast

FORBIDDEN_IMPORTS = {"requests", "urllib", "httpx", "subprocess", "socket", "selenium", "playwright", "paramiko", "ftplib"}
FORBIDDEN_CALL_NAMES = {"eval", "exec", "compile", "__import__", "open_url", "system", "popen"}
FORBIDDEN_TERMS = ["clinical_decision_automation", "auto_prescribe", "auto_diagnose", "browser automation", "credential capture"]

def run_static_audit(path: str | Path):
    base = Path(path)
    findings = []
    for py in base.rglob("*.py"):
        text = py.read_text(encoding="utf-8")
        if py.name != "static_audit.py":
            for term in FORBIDDEN_TERMS:
                if term in text.lower():
                    findings.append({"file": str(py), "type": "forbidden_term", "value": term})
        try:
            tree = ast.parse(text)
        except SyntaxError as e:
            findings.append({"file": str(py), "type": "syntax_error", "value": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    root = alias.name.split('.')[0]
                    if root in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "value": alias.name})
            if isinstance(node, ast.ImportFrom):
                root = (node.module or "").split('.')[0]
                if root in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(py), "type": "forbidden_import", "value": node.module})
            if isinstance(node, ast.Call):
                name = ""
                if isinstance(node.func, ast.Name):
                    name = node.func.id
                elif isinstance(node.func, ast.Attribute):
                    name = node.func.attr
                if name in FORBIDDEN_CALL_NAMES:
                    findings.append({"file": str(py), "type": "forbidden_call", "value": name})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, credential capture, clinical decision automation, transplant listing, or device actuation in offline core."
    }
