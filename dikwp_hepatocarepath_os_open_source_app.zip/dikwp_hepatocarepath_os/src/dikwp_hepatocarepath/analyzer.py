from __future__ import annotations
import json, math, re, hashlib
from pathlib import Path
from typing import Any, Dict, List, Tuple
from dataclasses import asdict
from .models import LiverPatientCase, DecisionCard, ActionTicket, AIModelCard, ReportBundle

RED_FLAG_TERMS = {
    "jaundice severe": ["deep jaundice", "yellow eyes worsening", "severe jaundice"],
    "confusion": ["confusion", "encephalopathy", "disoriented", "sleep reversal"],
    "bleeding": ["vomiting blood", "black stool", "melena", "hematemesis", "bleeding"],
    "ascites infection": ["fever with ascites", "abdominal pain with ascites"],
    "acute abdomen": ["severe abdominal pain", "rigid abdomen"],
    "shock": ["fainting", "low blood pressure", "shock"],
    "pregnancy liver risk": ["pregnant with jaundice", "pregnancy jaundice"],
    "drug injury risk": ["acetaminophen overdose", "herbal overdose", "unknown supplement injury"]
}

BLOCKED_REQUEST_PATTERNS = [
    r"write.*prescription", r"dose.*(antiviral|ribavirin|interferon|tenofovir|entecavir|diuretic|steroid)",
    r"diagnose.*patient", r"tell me.*treatment", r"ignore.*jaundice", r"avoid.*hospital",
    r"home cure.*liver failure", r"transplant.*not needed", r"stop.*antiviral", r"self medicate"
]

REVIEW_REQUEST_PATTERNS = [
    r"interpret.*lab", r"which drug", r"treatment plan", r"fibroscan", r"biopsy", r"antiviral",
    r"cirrhosis", r"hcc", r"transplant", r"ascites", r"varices", r"hepatic encephalopathy"
]

DISEASE_SIGNALS = {
    "HBV": ["HBsAg", "HBV DNA", "HBeAg", "hepatitis b"],
    "HCV": ["HCV RNA", "anti-HCV", "hepatitis c"],
    "MASLD/MASH": ["steatosis", "fatty liver", "MASLD", "MASH", "metabolic", "BMI", "diabetes"],
    "Alcohol-related liver disease": ["alcohol", "AUDIT", "heavy drinking"],
    "Cirrhosis / portal hypertension": ["platelets", "varices", "ascites", "splenomegaly", "nodular liver"],
    "HCC surveillance": ["AFP", "liver mass", "LI-RADS", "arterial enhancement", "washout"],
    "DILI / herb-supplement injury": ["herbal", "supplement", "new medication", "acetaminophen"],
    "Autoimmune / cholestatic": ["ANA", "AMA", "IgG", "ALP", "cholestasis", "PBC", "PSC"]
}

def load_case(path: str | Path) -> LiverPatientCase:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return LiverPatientCase(**data)

def _norm_text(case: LiverPatientCase) -> str:
    return json.dumps(asdict(case), ensure_ascii=False).lower()

def detect_red_flags(case: LiverPatientCase) -> List[str]:
    text = _norm_text(case)
    found = []
    for name, terms in RED_FLAG_TERMS.items():
        if any(t.lower() in text for t in terms):
            found.append(name)
    # Lab-based danger signals: deliberately simplified and review-only.
    labs = case.labs or {}
    try:
        inr = float(labs.get("INR", 0) or 0)
        bili = float(labs.get("total_bilirubin_umol_L", 0) or 0)
        alt = float(labs.get("ALT_U_L", 0) or 0)
        creat = float(labs.get("creatinine_umol_L", 0) or 0)
        if inr >= 1.5 and bili >= 50:
            found.append("possible acute liver failure pattern: INR and bilirubin elevated")
        if alt >= 1000:
            found.append("very high ALT: urgent clinician review")
        if creat >= 150:
            found.append("renal dysfunction with liver disease: urgent review")
    except Exception:
        pass
    return sorted(set(found))

def detect_topics(case: LiverPatientCase) -> List[str]:
    text = _norm_text(case)
    topics = []
    for topic, signals in DISEASE_SIGNALS.items():
        if any(s.lower() in text for s in signals):
            topics.append(topic)
    if not topics:
        topics.append("Unspecified liver disease / intake triage")
    return topics

def missing_evidence(case: LiverPatientCase, topics: List[str]) -> List[str]:
    missing = []
    labs = case.labs or {}; imaging = case.imaging or {}; virology = case.virology or {}; history = case.history or {}
    common = ["ALT_U_L", "AST_U_L", "total_bilirubin_umol_L", "albumin_g_L", "platelets_10e9_L", "INR"]
    for k in common:
        if k not in labs or labs.get(k) in [None, "", "unknown"]:
            missing.append(k)
    if not imaging.get("ultrasound_date") and not imaging.get("ct_mri_date"):
        missing.append("recent liver imaging date")
    if "HBV" in topics:
        for k in ["HBsAg", "HBV_DNA_IU_mL", "HBeAg", "anti_HBs"]:
            if k not in virology:
                missing.append(k)
    if "HCV" in topics and "HCV_RNA_IU_mL" not in virology:
        missing.append("HCV_RNA_IU_mL")
    if "MASLD/MASH" in topics:
        for k in ["BMI", "HbA1c", "lipids", "blood_pressure"]:
            if k not in history and k not in labs:
                missing.append(k)
    if "Cirrhosis / portal hypertension" in topics:
        for k in ["varices_screening", "ascites_assessment", "encephalopathy_history"]:
            if k not in history and k not in imaging:
                missing.append(k)
    return sorted(set(missing))

def risk_score(case: LiverPatientCase, red_flags: List[str], missing: List[str], topics: List[str]) -> float:
    score = 0.15
    score += min(len(red_flags) * 0.18, 0.55)
    if "Cirrhosis / portal hypertension" in topics: score += 0.12
    if "HCC surveillance" in topics: score += 0.16
    if "DILI / herb-supplement injury" in topics: score += 0.08
    score += min(len(missing) * 0.018, 0.18)
    return round(min(score, 1.0), 3)

def route_decision(score: float, red_flags: List[str], topics: List[str]) -> Tuple[str, str, str]:
    if red_flags:
        return "urgent_specialist_or_emergency_review", "high", "hepatology/emergency clinician"
    if score >= 0.7 or "HCC surveillance" in topics:
        return "specialist_hepatology_review_required", "high", "hepatologist / liver tumor board"
    if score >= 0.45 or "Cirrhosis / portal hypertension" in topics:
        return "clinician_review_required", "medium", "hepatology clinician"
    return "education_and_triage_prep_only", "low", "primary care / hepatology nurse educator"

def semantic_stability(missing: List[str], red_flags: List[str]) -> str:
    if red_flags:
        return "S2 Provisional Closure: urgent red-flag routing overrides incomplete semantic closure"
    if len(missing) >= 8:
        return "S2 Provisional Closure: many key anchors missing"
    if len(missing) >= 3:
        return "S3 Supported Closure: usable triage with residual evidence queue"
    return "S4 Stable Operational Closure: sufficient anchors for review preparation"

def build_dikwp_ledger(case: LiverPatientCase, topics: List[str], red_flags: List[str], missing: List[str], route: str) -> List[Dict[str, Any]]:
    return [{
        "object": case.case_id,
        "D": {"symptoms": case.symptoms, "labs": case.labs, "imaging": case.imaging, "virology": case.virology},
        "I": {"topics": topics, "red_flags": red_flags, "missing_evidence": missing, "setting": case.setting},
        "K": {"mechanism_layer": "liver disease triage, treatment preparation, rehabilitation support, surveillance readiness"},
        "W": {"boundaries": ["no diagnosis", "no prescribing", "no procedure scheduling", "clinician final responsibility"]},
        "P": {"goal": "prepare safer hepatology triage/treatment review/rehab workflow", "value": "reduce missed red flags and evidence gaps", "constraints": ["review-only", "patient safety", "privacy"], "feedback": "clinician review updates ledger"},
        "R": {"route": route, "reliability": "Supported / RunProof for demo; clinical reliability requires local validation"}
    }]

def build_treatment_prep(case: LiverPatientCase, topics: List[str], missing: List[str]) -> Dict[str, Any]:
    prep = {
        "purpose": "prepare clinician review, not prescribe or decide treatment",
        "topic_specific_questions": [],
        "baseline_evidence_to_collect": missing,
        "contraindication_and_interaction_review": ["pregnancy status where relevant", "renal function", "current medications", "herbal/supplement use", "alcohol use", "decompensation signs"],
        "followup_outcomes_to_track": ["symptom changes", "liver enzymes", "bilirubin/INR/albumin/platelets", "imaging/surveillance dates", "patient-reported fatigue/itch/pain", "adherence barriers"]
    }
    if "HBV" in topics:
        prep["topic_specific_questions"].extend(["Confirm HBV phase and fibrosis stage with clinician", "Review antiviral eligibility and monitoring by hepatology clinician", "Check household vaccination/counseling needs"])
    if "HCV" in topics:
        prep["topic_specific_questions"].extend(["Confirm active HCV RNA", "Prepare medication interaction list for clinician", "Review linkage-to-care and post-treatment confirmation plan"])
    if "MASLD/MASH" in topics:
        prep["topic_specific_questions"].extend(["Clarify metabolic risk factors", "Prepare weight, diabetes, lipid and blood pressure data", "Discuss fibrosis risk staging and lifestyle support with clinician"])
    if "Cirrhosis / portal hypertension" in topics:
        prep["topic_specific_questions"].extend(["Check decompensation history", "Prepare varices/ascites/encephalopathy surveillance questions", "Create urgent escalation education"])
    if "HCC surveillance" in topics:
        prep["topic_specific_questions"].extend(["Confirm imaging features with liver tumor board", "Do not infer diagnosis from AFP alone", "Prepare multidisciplinary review packet"])
    if not prep["topic_specific_questions"]:
        prep["topic_specific_questions"].append("Clarify liver disease etiology, stage, urgency and review pathway with clinician")
    return prep

def build_rehab_plan(case: LiverPatientCase, topics: List[str], red_flags: List[str]) -> Dict[str, Any]:
    route = "pause_rehab_until_urgent_review" if red_flags else "clinician_supervised_rehabilitation_support"
    return {
        "route": route,
        "nutrition_support": ["avoid one-size-fits-all diet claims", "screen for malnutrition risk if cirrhosis/frailty suspected", "coordinate with dietitian when available"],
        "activity_support": ["graded activity after clinician clearance", "fatigue pacing", "avoid unsafe intense exercise during acute illness"],
        "alcohol_and_substance_support": ["screen and support cessation/reduction pathway where relevant", "avoid shame-based counseling"],
        "medication_safety": ["keep medication/supplement list", "ask clinician before stopping or starting drugs", "avoid self-directed dosing"],
        "mental_health_and_stigma": ["screen for anxiety, stigma, sleep disruption", "support peer/community resources"],
        "followup_adherence": ["appointment calendar", "lab/imaging tracking", "barrier log: cost, transport, work, family"],
        "patient_goals": case.patient_goals
    }

def guard_ai_request(text: str) -> Dict[str, Any]:
    lower = text.lower()
    for pat in BLOCKED_REQUEST_PATTERNS:
        if re.search(pat, lower):
            return {"decision": "block", "reason": "request asks for diagnosis/prescribing/avoidance of care or unsafe self-management", "safe_redirect": "prepare questions for clinician or education-only explanation"}
    for pat in REVIEW_REQUEST_PATTERNS:
        if re.search(pat, lower):
            return {"decision": "clinician_review_required", "reason": "clinical interpretation/treatment-related request", "safe_redirect": "generate clinician handoff and evidence checklist"}
    return {"decision": "allow_education_or_admin_draft", "reason": "conceptual or administrative education request", "safe_redirect": "keep residuals and cite sources"}

def build_patient_education(case: LiverPatientCase, red_flags: List[str], topics: List[str]) -> str:
    lines = ["# Patient Education Draft", "", "This draft is for clinician review before patient use. It is not a diagnosis or treatment instruction.", ""]
    if red_flags:
        lines.append("## Safety First")
        lines.append("Some symptoms or lab patterns in the record may require urgent clinical review. Do not use lifestyle or rehabilitation advice to delay urgent care.")
    lines.append("## What to Prepare for the Visit")
    lines.extend(["- Bring medication and supplement list.", "- Bring prior lab reports and imaging dates.", "- Write down symptoms, onset time, alcohol/supplement exposure, and patient goals.", "- Ask which findings are confirmed, suspected, or still unknown."])
    lines.append("## Follow-up Questions")
    for t in topics:
        lines.append(f"- For {t}: ask what evidence confirms this pathway, what remains uncertain, and what follow-up is needed.")
    lines.append("## Red Flag Reminder")
    lines.append("Seek urgent medical care for confusion, vomiting blood, black stools, severe abdominal pain, fainting, rapidly worsening jaundice, or fever with ascites.")
    return "\n".join(lines)

def build_clinician_handoff(case: LiverPatientCase, topics: List[str], red_flags: List[str], missing: List[str], route: str) -> str:
    return f"""# Clinician Handoff Draft

Case ID: {case.case_id}
Setting: {case.setting}

## Suspected Topic Signals
{chr(10).join('- ' + t for t in topics)}

## Red Flags
{chr(10).join('- ' + r for r in red_flags) if red_flags else '- None explicitly detected in the structured demo input'}

## Missing Evidence Queue
{chr(10).join('- ' + m for m in missing) if missing else '- No major missing anchors detected by the demo rules'}

## Proposed Route
{route}

## Boundary
This handoff prepares review. It does not diagnose, prescribe, stage disease, or schedule procedures.
"""

def analyze_case(case: LiverPatientCase) -> ReportBundle:
    topics = detect_topics(case)
    red_flags = detect_red_flags(case)
    missing = missing_evidence(case, topics)
    score = risk_score(case, red_flags, missing, topics)
    route, severity, reviewer = route_decision(score, red_flags, topics)
    stability = semantic_stability(missing, red_flags)
    decision_cards = [DecisionCard(case.case_id, "; ".join(topics), severity, route,
                                   "DIKWP triage based on topic signals, red flags, missing evidence, and review boundary.",
                                   reviewer, missing, red_flags, stability, "Supported / review-only prototype")]
    tickets = []
    priority = "P0" if red_flags else ("P1" if score >= 0.7 else "P2")
    tickets.append(ActionTicket("ticket-001", reviewer, priority, route,
                                "Review liver disease triage packet, missing evidence, and patient safety boundary.",
                                ["ledger-001"], "Return to clinician-managed review; do not act on AI-only outputs.",
                                ["new red flag", "worsening jaundice/confusion/bleeding", "missing INR/bilirubin in high-risk case", "patient asks for self-treatment"], True))
    triage_queue = [asdict(t) for t in tickets]
    ai_registry = [
        asdict(AIModelCard("hepatocare-triage-draft", "HepatoCare Triage Draft Agent", "prepare triage summary and missing evidence list", ["diagnosis", "prescribing", "procedure scheduling"], "local demo only", "C2 advisory", True)),
        asdict(AIModelCard("hepatocare-education-draft", "Patient Education Draft Agent", "draft patient education after clinician review", ["treatment instruction", "urgent care replacement"], "local demo only", "C1 draft", True)),
        asdict(AIModelCard("hepatocare-rehab-planner", "Liver Rehab Planner", "prepare rehab support checklist", ["exercise prescription during acute illness", "diet cure claims"], "local demo only", "C1 draft", True))
    ]
    summary = {
        "system": "DIKWP HepatoCarePath OS",
        "version": "0.1.0",
        "case_id": case.case_id,
        "topics": topics,
        "red_flags": red_flags,
        "missing_evidence_count": len(missing),
        "risk_score": score,
        "route": route,
        "severity": severity,
        "semantic_stability": stability,
        "safety_boundary": "No diagnosis, prescribing, procedure scheduling, transplant listing, or clinical automation. Human clinician review required."
    }
    return ReportBundle(
        summary=summary,
        dikwp_liver_ledger=build_dikwp_ledger(case, topics, red_flags, missing, route),
        decision_cards=[asdict(c) for c in decision_cards],
        action_tickets=[asdict(t) for t in tickets],
        triage_queue=triage_queue,
        treatment_prep_plan=build_treatment_prep(case, topics, missing),
        rehabilitation_plan=build_rehab_plan(case, topics, red_flags),
        patient_education_pack=build_patient_education(case, red_flags, topics),
        clinician_handoff=build_clinician_handoff(case, topics, red_flags, missing, route),
        ai_model_registry=ai_registry,
        safety_boundary=summary["safety_boundary"]
    )

def save_report(bundle: ReportBundle, outdir: str | Path) -> None:
    out = Path(outdir); out.mkdir(parents=True, exist_ok=True)
    data = asdict(bundle)
    (out / "hepatocare_report.json").write_text(json.dumps(data["summary"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "dikwp_liver_ledger.json").write_text(json.dumps(data["dikwp_liver_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "decision_cards.json").write_text(json.dumps(data["decision_cards"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "action_tickets.json").write_text(json.dumps(data["action_tickets"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "triage_queue.json").write_text(json.dumps(data["triage_queue"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "treatment_prep_plan.json").write_text(json.dumps(data["treatment_prep_plan"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "rehabilitation_plan.json").write_text(json.dumps(data["rehabilitation_plan"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out / "patient_education_pack.md").write_text(bundle.patient_education_pack, encoding="utf-8")
    (out / "clinician_handoff.md").write_text(bundle.clinician_handoff, encoding="utf-8")
    (out / "ai_model_registry.json").write_text(json.dumps(data["ai_model_registry"], ensure_ascii=False, indent=2), encoding="utf-8")
    recs = ["# Recommendations", "", "- Use this output only as a review packet.", "- Confirm urgency, diagnosis, staging, and treatment with licensed clinicians.", "- Keep patient identity and sensitive data out of demo workflows.", "- Run local validation before any real clinical deployment."]
    (out / "recommendations.md").write_text("\n".join(recs), encoding="utf-8")
