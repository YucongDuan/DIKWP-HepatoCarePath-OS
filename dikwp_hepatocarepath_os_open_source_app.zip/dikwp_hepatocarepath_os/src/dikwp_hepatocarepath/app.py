# Optional Streamlit app. The offline core does not require Streamlit.
try:
    import streamlit as st
except Exception:  # pragma: no cover
    st = None

from .analyzer import load_case, analyze_case


def main():
    if st is None:
        print("Streamlit not installed. Use CLI instead.")
        return
    st.title("DIKWP HepatoCarePath OS")
    st.caption("Review-only liver hospital triage, treatment-prep and rehabilitation governance demo.")
    uploaded = st.file_uploader("Upload case JSON", type=["json"])
    if uploaded:
        import json, tempfile
        data = uploaded.read().decode("utf-8")
        with tempfile.NamedTemporaryFile("w", delete=False, suffix=".json", encoding="utf-8") as f:
            f.write(data); p = f.name
        case = load_case(p)
        bundle = analyze_case(case)
        st.json(bundle.summary)
        st.subheader("Clinician Handoff")
        st.markdown(bundle.clinician_handoff)

if __name__ == "__main__":
    main()
