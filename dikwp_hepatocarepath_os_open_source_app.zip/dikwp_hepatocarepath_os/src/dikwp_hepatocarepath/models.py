from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional

@dataclass
class LiverPatientCase:
    case_id: str
    setting: str
    patient_profile: Dict[str, Any]
    symptoms: List[str]
    history: Dict[str, Any]
    labs: Dict[str, Any]
    imaging: Dict[str, Any]
    virology: Dict[str, Any]
    lifestyle: Dict[str, Any]
    medications: List[str]
    patient_goals: List[str]
    ai_requests: List[str] = field(default_factory=list)

@dataclass
class DecisionCard:
    case_id: str
    topic: str
    severity: str
    route: str
    rationale: str
    required_reviewer: str
    missing_evidence: List[str]
    red_flags: List[str]
    semantic_stability: str
    reliability: str

@dataclass
class ActionTicket:
    ticket_id: str
    owner: str
    priority: str
    route: str
    action: str
    evidence_refs: List[str]
    rollback_plan: str
    kill_conditions: List[str]
    human_confirmation_required: bool

@dataclass
class AIModelCard:
    model_id: str
    name: str
    intended_use: str
    prohibited_uses: List[str]
    validation_status: str
    max_control_level: str
    clinician_review_required: bool

@dataclass
class ReportBundle:
    summary: Dict[str, Any]
    dikwp_liver_ledger: List[Dict[str, Any]]
    decision_cards: List[Dict[str, Any]]
    action_tickets: List[Dict[str, Any]]
    triage_queue: List[Dict[str, Any]]
    treatment_prep_plan: Dict[str, Any]
    rehabilitation_plan: Dict[str, Any]
    patient_education_pack: str
    clinician_handoff: str
    ai_model_registry: List[Dict[str, Any]]
    safety_boundary: str
